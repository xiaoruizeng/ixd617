<!--
共享资产：本文件由 ux-user-research-master 维护，ux-user-research-insights-articulation 以只读方式引用。
两者同属 skills/ 版本库，引用路径 ../ux-user-research-master/references/case-example-zolo.md 在库内解析。
移动或重命名前请同步更新两个技能的 SKILL.md 引用路径。
-->

# 用户研究案例：ZOLO 网站可用性测试

> **案例类型**：可用性测试 + 深度访谈
> **研究目标**：评估网站服务传达的清晰度，发现用户理解障碍，提出改进建议

---

## 一、研究背景

ZOLO 是一个面向餐厅供应商的 B2B SaaS 平台，提供订单管理、库存追踪等服务。研究目标是评估网站能否有效传达其服务价值，识别用户在理解和使用过程中的障碍。

---

## 二、Insight 1：网站未能有效传达服务内容

### 关键发现

**ZOLO's website failed to communicate its services. While 88% of users understood the basic concept of ZOLO's offerings, 92% found it challenging to understand the services and benefits offered by ZOLO due to readability issues and unclear information provided.**

> ZOLO 的网站没有清晰传达其服务。
> 尽管 88% 的用户理解了 ZOLO 的基本概念，但 92% 的用户觉得难以阅读理解。这导致用户可能丧失对 ZOLO 服务的兴趣信任状态。

---

### 进一步揭示 Why / How / What

#### 问题1：不知道背后是谁

**Not knowing who was behind ZOLO and who it was designed for** made 92.8% of survey users (n=34) feel unsure and hesitant to sign up.

> 用户不知道 ZOLO 的创始人是谁，不知道这个产品是给谁用的。这让 92% 的用户觉得难以阅读不明确，这可能导致对 ZOLO 服务缺乏兴趣和信任。

#### 问题2：不知道产品究竟是干嘛的

Usability testing and user interviews further revealed that users couldn't immediately understand ZOLO's core services without scrolling down the website. The lack of specifics about how ZOLO works and its user benefits resulted in confusion among users regarding its offerings.

> 在进一步的可用性测试访谈中，用户需要一直往下滑动才能知道 ZOLO 的核心服务。"当我第一次看到这个问题页内容，所以用户"要从头到尾看到产品才可以了解 ZOLO 怎么运作和好处是什么"。这导致用户对 ZOLO 的认知非常浅，导致没有深一步去做，不能全面了解它的所有功能。

**具体表现**：

| 维度 | 问题 |
|------|------|
| Unclear Target Audience | 不清楚目标用户是谁 |
| Lack of Benefit Explanation | 缺乏好处说明 |

#### 问题3：核心功能描述模糊

**Unclear information on features like "50 broadcasts per month" and "30k messages per month"** further added to the confusion. This ambiguity led to an impression of incompleteness, impacting user trust and decision-making.

> 我看"每月50次广播"、"每月3万条消息"究竟是什么意思，我也不太清楚。用户说：
> - "不知道这些是给我的还是接收者的数据...什么是 50 broadcasts？"
> - "这些数字听起来很多，但不知道究竟是不是我需要的"

---

### 典型用户语录

| 语录 | 分类 |
|------|------|
| "I felt a bit under-whelmed and didn't understand what this website offers" | 首次印象困惑 |
| "I took me a while to understand what ZOLO offers towards the end of the website" | 信息获取困难 |
| "Wish it was clear who the website is for like it's designed for restaurant owners and chefs" | 目标用户不清 |
| "The website copy should be cleaner for customers who skip the video or didn't notice it. I only understood the product offerings after watching the video" | 依赖视频才能理解 |

---

### 设计建议

#### Recommendation 1

**Enhance user understanding of ZOLO and its services through simplified language and a clear hierarchical structure, addressing user confusion and improving website readability.**

> 通过简洁的语言和清晰的层次结构来帮助用户更好地了解 ZOLO 的服务，提高网站的可读性。

---

#### 具体方案1：首屏价值主张

**Display ZOLO's value proposition above the fold** with concise messaging and a hero image that reflects the primary service, to provide users with an immediate understanding of the core service.

> 在首屏展示 ZOLO 的价值主张，配合简洁的文案和反映核心服务的主图，让用户立刻理解核心服务。

**改版前后对比**：

| Before | After |
|--------|-------|
| "Most powerful tool for food suppliers" | "Sell more with less friction" |
| 模糊的营销语言 | 直接说明用户价值 |
| Hero 图片与服务无关 | Hero 图片展示实际使用场景 |

---

#### 具体方案2：清晰传达服务和价值主张

**Communicate the benefits of ZOLO's services and value proposition clearly** by providing time-saving benefits and detailed information on its features and functionality.

> 清晰传达 ZOLO 服务的好处和价值主张，提供节省时间的好处以及功能的详细信息。

**改版要点**：
- Important Feature Access：突出最重要的功能入口
- Time-saving rate image：展示节省时间的数据可视化
- Detailed feature & benefits Proposition：详细的功能和好处说明

---

#### 具体方案3：优先展示用户最关注的功能

**Prioritize user-relevant features like Text-to-Order** (favoured by 88% of users) for easy discovery.

> 优先展示用户最关注的功能，如 Text-to-Order（88% 的用户偏好），方便用户发现。

---

#### 具体方案4：增加创始人故事和客户案例

**Enhance user understanding of ZOLO and its services** through founder and customer stories that showcase memorable values.

> 通过创始人故事和客户案例来增强用户对 ZOLO 及其服务的理解。

**改版要点**：
- Building Trust and Connection：建立信任和连接
- Share founder and customer stories to build trust and empathy amongst target audience

---

#### 具体方案5：灵活的定价展示

**Explore our pricing options**

**Distinctive Pricing Options**：
- Toggle between monthly and yearly pricing
- Choose between pricing options (e.g. lite, basic, premium, enterprise)
- Include details for each pricing plan

**改版要点**：
- Include a "Sign Up" CTA to encourage users to sign up for a free trial to experience firsthand how ZOLO can streamline their operations and empower informed decision-making
- Offer users the flexibility to choose the ZOLO plan that best suits their business needs with transparent and flexible pricing plans

---

## 三、改版成效

**After restructuring the website content, our recent usability test revealed that all users found it easier to access information about ZOLO's services and benefits.**

> 重构网站内容后，最新的可用性测试显示，所有用户都更容易获取 ZOLO 服务和好处的信息。

| 维度 | Before | After |
|------|--------|-------|
| Clearer Target Information | ❌ 不清楚 | ✅ 首屏明确展示目标用户 |
| Concise communication of features and how users can access the features | ❌ 模糊 | ✅ 功能说明简洁，入口清晰 |
| More sales conversion "that's what the see if for me" | ❌ 低转化 | ✅ 用户说"这正是我需要的" |

---

## Insight 2：网站语气过于严肃，缺乏亲和力

### 关键发现

**Nearly all users (97%, n=34) preferred a friendlier and more approachable tone for ZOLO's website, indicating the current tone may not resonate well with users.**

> 几乎所有用户（97%，n=34）都更偏好一个更友好、更平易近人的网站语气，这表明当前的语气可能无法与用户产生共鸣。

---

### 进一步揭示 Why / How / What

#### 问题表现：用户感到与品牌有隔阂

During the interview, users also gave feedback on **experiencing a disconnect with ZOLO due to the serious and disengaging tone**. This disconnect was further emphasised by their preference for a more approachable tone that resonates with them.

> 在访谈中，用户反馈他们**因为网站过于严肃和缺乏吸引力的语气而感到与 ZOLO 有隔阂**。他们强烈偏好一个更平易近人、能与他们产生共鸣的语气。

#### 原版网站的问题

**The original ZOLO website before the redesign:**

| 问题区域 | 具体表现 |
|----------|----------|
| 标题文案 | "MOST POWERFUL SALES TOOL FOR FOOD SUPPLIERS" - 过于生硬的营销语言 |
| 副标题 | "Power up your communications, ordering and payments with ZOLO" - 缺乏温度 |
| 整体语气 | "Most powerful tool for food suppliers" - 严肃、不够友好 |
| 视频语气 | AI 角色的声音单调，不够友好 |

#### 可用性测试中的发现

**Concerns about the website's tone surfaced during usability testing.** Words like "serious" and "lacking in friendliness" were frequently used by users to describe their experience.

> 关于网站语气的担忧在可用性测试中浮出水面。用户频繁使用"严肃"和"缺乏友好感"等词来描述他们的体验。

**Users in usability testing mentioned feeling a disconnect with the website's serious tone.**

> 可用性测试中的用户提到，他们感到与网站严肃的语气有隔阂。

---

### 典型用户语录

| 语录 | 问题类型 |
|------|----------|
| "The tone of voice is a bit serious and not engaging enough." | 语气过于严肃 |
| "The AI character in the video sounds monotone and doesn't appear friendly." | 视频 AI 角色单调不友好 |
| "Have a more approachable and easy reading structure than a monotone." | 希望更平易近人 |
| "The tone of voice for the video is too serious and slow." | 视频语气太严肃太慢 |

*Insights from user research with F&B professionals we surveyed and interviewed*

---

### 设计建议

#### Recommendation 2

**Refresh the website's tone to foster deeper connections and make the brand more relatable with users.**

> 刷新网站的语气，以建立更深层的连接，让品牌与用户更有共鸣。

---

#### 具体方案：更友好、更有温度的语气

**Bridge the disconnect** by adopting a friendly and approachable tone that resonates with users, fostering connection and understanding.

> 通过采用友好、平易近人的语气来消除隔阂，与用户产生共鸣，建立连接和理解。

**改版前后对比**：

| 维度 | Before | After |
|------|--------|-------|
| **主标题** | "MOST POWERFUL SALES TOOL FOR FOOD SUPPLIERS" | "Sell more with less frictions" |
| **语气定位** | 严肃、生硬、营销感强 | 友好、平易近人、有温度 |
| **品牌故事** | 无 | "Get to know us" - 介绍创始人故事 |
| **功能描述** | 技术导向 | 用户价值导向："Text to orders - Process your orders quickly and smartly" |

**Redesigned website showcasing ZOLO's expertise and partnerships:**

| 改版要点 | 具体内容 |
|----------|----------|
| **Refresh the website's tone** | to be friendlier for a welcoming and engaging experience |
| **Get to know us** | "More than 35% of food being wasted even before it reaches end consumers" - 用数据讲故事 |
| **How we began** | "ZOLO stemmed from facing the same challenges with the founding team working within the industry" - 创始人故事建立共鸣 |
| **Text to orders** | "Process your orders quickly and smartly. Automatically convert text messages to formal purchase orders to minimize cost and mistakes." - 清晰说明用户价值 |

---

### 改版成效

#### Outcome

**After the website's tone refresh, user feedback indicated a better alignment with their preferences and perceived the brand as more relatable and approachable.**

> 网站语气刷新后，用户反馈表明品牌与他们的偏好更加一致，用户认为品牌更有亲和力、更平易近人。

---

## Insight 3：缺乏社会认证导致用户质疑可信度

### 关键发现

**The lack of social proof made potential users question ZOLO's credibility and hesitate to sign up for its services.**

> 缺乏社会认证使潜在用户质疑 ZOLO 的可信度，并对注册其服务犹豫不决。

---

### 进一步揭示 Why / How / What

#### 问题表现：用户对初创公司缺乏信任

During user interviews, a key concern emerged: **potential users expressed hesitation to sign up for ZOLO, a new startup, wondering if the company could deliver on its promises.**

> 在用户访谈中，一个关键担忧浮现：**潜在用户对注册 ZOLO 这个新创公司表示犹豫，怀疑公司能否兑现承诺。**

#### 根本原因：缺乏用户评价和案例

**This lack of testimonials or user reviews**, which could build trust and showcase the impact on users' work processes, **made it difficult for them to assess ZOLO's credibility and legitimacy.**

> **缺乏用户评价或用户案例**——这些本可以建立信任并展示对用户工作流程的影响——**使用户难以评估 ZOLO 的可信度和合法性。**

---

### 典型用户语录

| 语录 | 问题类型 |
|------|----------|
| "No testimonials to show credibility." | 缺乏信任背书 |
| "The website is not convincing enough to click 'Get Started'." | 说服力不足 |
| "What we know about you should be upfront to let the audience identify with the product and to see possible use cases." | 信息前置需求 |
| "There aren't any case studies to check out how the features have been implemented." | 缺乏案例研究 |

*Insights from user research with F&B professionals we surveyed and interviewed*

---

### 设计建议

#### Recommendation 3

**Leverage social proof from companies that have joined ZOLO's launch and team expertise to build trust and convince users to try ZOLO.**

> 利用已加入 ZOLO 发布的公司的社会认证和团队专业能力来建立信任，说服用户尝试 ZOLO。

---

#### 具体方案1：通过专业能力建立信心

**Confidence through Expertise**

**Establish credibility** by highlighting the team's proven expertise and experience to assure potential users they are in capable hands.

> 通过突出团队已验证的专业能力和经验来**建立可信度**，让潜在用户相信他们选择了可靠的合作伙伴。

**改版要点**：

| 模块 | 内容 |
|------|------|
| **Get to know us** | "More than 35% of food being wasted even before it reaches end consumers." |
| **How we began** | "ZOLO stemmed from facing the same challenges with the founding team working within the industry." |
| **团队背景** | "With a strong desire to solve these problems for our peers, we married industry experience and technology expertise to bring a world-class solution to South-east Asia." |

> Highlight the founder's experience builds user confidence in ZOLO's team.
> 突出创始人的经验，建立用户对 ZOLO 团队的信心。

---

#### 具体方案2：通过合作伙伴建立信任

**Building Trust through Partnerships**

**Build confidence and trust** in potential users by showcasing ZOLO's partnerships with companies to demonstrate the value of its services.

> 通过展示 ZOLO 与其他公司的合作关系来**建立潜在用户的信心和信任**，证明其服务的价值。

**改版要点**：

| 模块 | 内容 |
|------|------|
| **Join the launch together with** | 展示合作伙伴 logo |
| **合作品牌** | foodXservices, INDOGUNA SINGAPORE, TAT'S THE DIFFERENCE, Nestlé, POUR BUCHA 等 |
| **说明** | Feature logos of well-known brands or respected companies partnered with ZOLO at launch to build trust and validate its expertise in the industry. |

> 展示知名品牌或受尊敬的公司的 logo，这些公司在 ZOLO 发布时与其合作，以建立信任并验证其在行业中的专业能力。

---

#### 未来建议：客户成功案例

As ZOLO's client base grows, **sharing success stories of how businesses have benefited from its services** can build trust with potential clients and highlight the value ZOLO delivers.

> 随着 ZOLO 客户群的增长，**分享企业如何从其服务中受益的成功案例**可以与潜在客户建立信任，并突出 ZOLO 提供的价值。

---

### 改版成效

#### Outcome

**Following recent website design changes, user testing has shown a positive shift in user perception of the brand. Users now find the brand more reliable and are more likely to sign up for the service.**

> 在最近的网站设计改版后，用户测试显示用户对品牌的认知发生了积极转变。用户现在认为品牌更可靠，更愿意注册服务。

---

## 四、案例总结：用研结论的写法拆解

### 三个 Insight 的结构对比

| 维度 | Insight 1 | Insight 2 | Insight 3 |
|------|-----------|-----------|-----------|
| **核心发现** | 网站未能有效传达服务内容 | 网站语气过于严肃，缺乏亲和力 | 缺乏社会认证导致用户质疑可信度 |
| **量化数据** | 88% 理解基本概念，92% 觉得难以理解 | 97% 偏好更友好的语气 | - |
| **问题拆解** | 不知道是谁、不知道干嘛、功能描述模糊 | 语气严肃、视频单调、缺乏共鸣 | 缺乏用户评价、缺乏案例研究 |
| **典型语录** | 4条 | 4条 | 4条 |
| **设计建议** | 简化语言 + 清晰层次（5个具体方案） | 刷新语气 + 建立连接 | 社会认证 + 专业能力 + 合作伙伴 |
| **改版成效** | 所有用户更容易获取信息 | 用户认为品牌更有亲和力 | 用户认为品牌更可靠，更愿意注册 |

### 结构拆解

```
┌─────────────────────────────────────────────────────────────────┐
│ Insight 1: 关键发现（一句话核心洞察）                             │
│ ZOLO's website failed to communicate its services.              │
├─────────────────────────────────────────────────────────────────┤
│ 高频痛点 + 计算反馈人数                                          │
│ 88% understood basic concept, 92% found it challenging          │
├─────────────────────────────────────────────────────────────────┤
│ 进一步揭示 Why / How / What                                      │
│ ├── 问题1：不知道背后是谁                                        │
│ ├── 问题2：不知道产品干嘛的                                      │
│ └── 问题3：核心功能描述模糊                                      │
├─────────────────────────────────────────────────────────────────┤
│ 挑选典型行为/语录                                                │
│ "I felt a bit under-whelmed..."                                 │
│ "I took me a while to understand..."                            │
├─────────────────────────────────────────────────────────────────┤
│ 给出设计建议（设计目标 + 设计方案）                               │
│ ├── Recommendation 1: 简化语言 + 清晰层次                        │
│ ├── 方案1: 首屏价值主张                                         │
│ ├── 方案2: 清晰传达服务和价值                                    │
│ ├── 方案3: 优先展示用户最关注的功能                              │
│ ├── 方案4: 增加创始人故事和客户案例                              │
│ └── 方案5: 灵活的定价展示                                       │
├─────────────────────────────────────────────────────────────────┤
│ 改版成效                                                        │
│ All users found it easier to access information                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ Insight 2: 关键发现（一句话核心洞察）                             │
│ Nearly all users (97%) preferred a friendlier tone              │
├─────────────────────────────────────────────────────────────────┤
│ 高频痛点 + 计算反馈人数                                          │
│ 97% preferred friendlier and more approachable tone             │
├─────────────────────────────────────────────────────────────────┤
│ 进一步揭示 Why / How / What                                      │
│ ├── 问题表现：用户感到与品牌有隔阂                                │
│ ├── 原版问题：标题生硬、语气严肃、视频单调                        │
│ └── 可用性测试：频繁使用"serious""lacking friendliness"          │
├─────────────────────────────────────────────────────────────────┤
│ 挑选典型行为/语录                                                │
│ "The tone of voice is a bit serious and not engaging enough."   │
│ "The AI character in the video sounds monotone..."              │
├─────────────────────────────────────────────────────────────────┤
│ 给出设计建议（设计目标 + 设计方案）                               │
│ ├── Recommendation 2: 刷新语气，建立更深层连接                    │
│ ├── 方案: 采用友好、平易近人的语气                               │
│ ├── Before/After 对比                                           │
│ └── 增加创始人故事、用户价值导向的功能描述                        │
├─────────────────────────────────────────────────────────────────┤
│ 改版成效                                                        │
│ Users perceived the brand as more relatable and approachable    │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ Insight 3: 关键发现（一句话核心洞察）                             │
│ The lack of social proof made users question ZOLO's credibility │
├─────────────────────────────────────────────────────────────────┤
│ 进一步揭示 Why / How / What                                      │
│ ├── 问题表现：用户对初创公司缺乏信任                              │
│ └── 根本原因：缺乏用户评价和案例研究                              │
├─────────────────────────────────────────────────────────────────┤
│ 挑选典型行为/语录                                                │
│ "No testimonials to show credibility."                          │
│ "The website is not convincing enough to click 'Get Started'."  │
│ "There aren't any case studies to check out..."                 │
├─────────────────────────────────────────────────────────────────┤
│ 给出设计建议（设计目标 + 设计方案）                               │
│ ├── Recommendation 3: 利用社会认证和团队专业能力建立信任          │
│ ├── 方案1: Confidence through Expertise（创始人故事）            │
│ ├── 方案2: Building Trust through Partnerships（合作伙伴logo）   │
│ └── 未来建议: 客户成功案例                                       │
├─────────────────────────────────────────────────────────────────┤
│ 改版成效                                                        │
│ Users now find the brand more reliable and more likely to sign up│
└─────────────────────────────────────────────────────────────────┘
```

### 亮点总结

| 亮点 | Insight 1 | Insight 2 | Insight 3 |
|------|-----------|-----------|-----------|
| **量化支撑** | 88%、92%、92.8%、88% of users favoured | 97% preferred friendlier tone | 定性为主 |
| **语录佐证** | 4条真实用户语录 | 4条真实用户语录 | 4条真实用户语录 |
| **问题拆解** | 不清楚→3个具体原因 | 语气问题→具体表现 | 缺乏信任→2个根因 |
| **建议可执行** | 5个具体方案 | Before/After对比 | 2个具体方案+未来建议 |
| **成效验证** | 可用性测试结果 | 用户反馈 | 用户认知转变 |

### 完整案例的结构特点

```
完整用研报告
│
├── Insight 1：功能层面（服务传达不清）
│   ├── 问题：信息架构、内容可读性
│   └── 建议：简化语言、清晰层次、首屏价值主张
│
├── Insight 2：情感层面（语气过于严肃）
│   ├── 问题：品牌调性、用户共鸣
│   └── 建议：刷新语气、创始人故事
│
└── Insight 3：信任层面（缺乏社会认证）
    ├── 问题：可信度、合法性
    └── 建议：专业能力展示、合作伙伴背书、客户案例
```

---

## 五、面试表达模板

> 我负责 ZOLO 网站的用户研究。ZOLO 是一个 B2B SaaS 平台，帮助餐厅供应商管理订单。
>
> **研究目标**：评估网站能否有效传达其服务价值，识别用户注册的障碍。
>
> **研究方法**：问卷调研（n=34）+ 可用性测试 + 深度访谈
>
> **核心发现1：服务传达不清**
> 虽然 88% 的用户理解了 ZOLO 的基本概念，但 92% 的用户表示难以理解具体的服务和好处。
> - 用户不知道产品是给谁用的
> - 需要滑动很久才能理解核心服务
> - 功能描述（如"每月50次广播"）让人困惑
>
> **设计建议1**：首屏明确展示价值主张、简化功能描述、增加创始人故事
>
> **核心发现2：语气过于严肃**
> 97% 的用户偏好更友好、更平易近人的网站语气。用户频繁使用"严肃""缺乏友好感"来描述体验。
>
> **设计建议2**：刷新网站语气，从"MOST POWERFUL SALES TOOL"改为"Sell more with less frictions"
>
> **核心发现3：缺乏社会认证**
> 用户因缺乏用户评价和案例研究而质疑 ZOLO 的可信度，犹豫是否注册。用户说"No testimonials to show credibility"。
>
> **设计建议3**：
> 1. 通过专业能力建立信心：展示创始人经验和团队背景
> 2. 通过合作伙伴建立信任：展示知名品牌合作伙伴 logo
> 3. 未来增加客户成功案例
>
> **改版成效**：
> - 所有用户都能更轻松地理解 ZOLO 的服务和价值
> - 用户认为品牌更有亲和力、更平易近人
> - 用户认为品牌更可靠，更愿意注册服务
